import java.util.*;
@FunctionalInterface
interface AmazonDeliverySystem {
    void deliver(List<Product> products);
    static  void trackDelivery(List<Product> products,double total) {
        String user="Salim";
        int otp=121;
        double pay=total;

        for (Product product : products) {
            System.out.println("Tracking delivery status for " + product.getName());
            System.out.println("Your " + product.getName() + " is out for delivery.");
            if(otp==121 && user.equals("Salim") && pay==total)
            {
                System.out.println("......................");
                System.out.println("Authentication and Payment successfully");
                System.out.println("Your " + product.getName() + " has been successfully delivered.");
            }
            else
                System.out.println("User Not Valid");
        }
    }
    static void dispatch(List<Product> products) {
        for (Product product : products) {
            System.out.println("Dispatching " + product.getName() + " for delivery.");
            System.out.println(product.getName() + " has been dispatched.");
        }
    }
}
