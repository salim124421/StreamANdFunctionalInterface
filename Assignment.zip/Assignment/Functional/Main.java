import java.util.Arrays;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        // Products to be delivered
        List<Product> productList = Arrays.asList(
                new Product("iPhone", 1000, 3),
                new Product("MacBook", 2000, 1),
                new Product("Apple Watch", 500, 2)
        );

        final AmazonDeliverySystem finalOrderPlacement = orderedProducts -> {
            System.out.println("Order placed for the following products:");
            for (Product product : orderedProducts) {
                System.out.println("- " + product.getQuantity() + "x " + product.getName() + " ( ₹" + product.getPrice() + ")");
            }

            System.out.println(".........................");
            AmazonDeliverySystem.dispatch(orderedProducts); // Step 2: Dispatch
            System.out.println("....................");
            delivery(orderedProducts); // Step 3: Delivery
            System.out.println("....................");
            AmazonDeliverySystem.trackDelivery(orderedProducts,generateInvoice(productList)); // Step 4: Tracking
            System.out.println("......................");
            generateInvoice(orderedProducts); // Generate invoice
        };
        finalOrderPlacement.deliver(productList);
    }
    // Delivery
    private static void delivery(List<Product> products) {
        System.out.println("Delivering the following products:");
        for (Product product : products) {
            System.out.println("- " + product.getQuantity() + "x " + product.getName());
        }
    }

    // Generate invoice
    private static double generateInvoice(List<Product> products) {
        System.out.println("\nInvoice:");
        double totalPrice = 0;
        for (Product product : products) {
            double itemPrice = product.getPrice();
            int quantity = product.getQuantity();
            double totalItemPrice = itemPrice * quantity;
            System.out.println("- " + product.getQuantity() + "x " + product.getName() + ":  ₹" + totalItemPrice);
            totalPrice += totalItemPrice;
        }
        System.out.println("Total:  ₹" + totalPrice);
        return  totalPrice;
    }
}