import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Creating employee data
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "Salim", Arrays.asList(
                new Salary(1, 10, 1, 2024),
                new Salary(2, 20, 2, 2024),
                new Salary(3,30, 3, 2024)
        ), 1, 2024, "InsightGeeks"));
        employees.add(new Employee(2, "Kashif", Arrays.asList(
                new Salary(4, 40, 1, 2024),
                new Salary(5, 50, 2, 2024),
                new Salary(6, 60, 3, 2024)
        ), 1, 2024, "Amazon"));
        employees.add(new Employee(3, "Aryan", Arrays.asList(
                new Salary(7, 70, 1, 2024),
                new Salary(8, 80, 2, 2024),
                new Salary(9, 90, 3, 2024)
        ), 1, 2024, "InsightGeeks"));
        employees.add(new Employee(4, "Saurabh", Arrays.asList(
                new Salary(10, 10, 1, 2024),
                new Salary(11, 20, 2, 2024),
                new Salary(12, 30, 3, 2024)
        ), 1, 2024, "Amazon"));

        // Q1: Calculate the total sum of salaries given by each company in the last 6 months
        Map<String, Integer> totalSalariesByCompany = calculateTotalSalariesByCompany(employees);
        System.out.println("1. Total salaries by company in the last 6 months:");
        System.out.println(totalSalariesByCompany);
        System.out.println();

        // Q2: Find the top salary for each month
        Map<Integer, Integer> topSalariesByMonth = findTopSalariesByMonth(employees);
        System.out.println("2. Top salary for each month:");
        System.out.println(topSalariesByMonth);
        System.out.println();

        // Q3: Calculate the month-wise percentage growth of salaries for each employee
        Map<String, Map<Integer, Double>> percentageGrowth = calculatePercentageGrowth(employees);
        System.out.println("3. Month-wise percentage growth of salaries for each employee:");
        System.out.println(percentageGrowth);
        System.out.println();

        // Q4: Make a list of all the employees in the specified format
        List<String> employeeList = createEmployeeList(employees);
        System.out.println("4. List of all employees in the specified format:");
        System.out.println(employeeList);
        System.out.println();

        // Q5: Make a company-wise map which shows the max salary given by the company each month
        Map<String, Map<Integer, Integer>> companyWiseMaxSalaryByMonth = findCompanyWiseMaxSalaryByMonth(employees);
        System.out.println("5. Company-wise map showing the max salary given by the company each month:");
        System.out.println(companyWiseMaxSalaryByMonth);
    }

    // Q1: Calculate the total sum of salaries given by each company in the last 6 months
    public static Map<String, Integer> calculateTotalSalariesByCompany(List<Employee> employees) {
        Map<String, Integer> totalSalariesByCompany = new HashMap<>();
        int currentYear = 2024;
        int currentMonth = 2; // February 2024

        try {
            for (Employee employee : employees) {
                int totalSalary = employee.getSalary().stream()
                        .filter(salary -> salary.getYear() == currentYear && salary.getMonth() >= currentMonth - 5)
                        .mapToInt(Salary::getAmount)
                        .sum();
                totalSalariesByCompany.put(employee.getCompany(), totalSalary);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in calculateTotalSalariesByCompany: " + e.getMessage());
            e.printStackTrace();
        }

        return totalSalariesByCompany;
    }

    // Q2: Find the top salary for each month
    public static Map<Integer, Integer> findTopSalariesByMonth(List<Employee> employees) {
        Map<Integer, Integer> topSalariesByMonth = new HashMap<>();

        try {
            for (Employee employee : employees) {
                for (Salary salary : employee.getSalary()) {
                    int currentSalary = salary.getAmount();
                    int currentMonth = salary.getMonth();
                    topSalariesByMonth.put(currentMonth, Math.max(topSalariesByMonth.getOrDefault(currentMonth, 0), currentSalary));
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred in findTopSalariesByMonth: " + e.getMessage());
            e.printStackTrace();
        }

        return topSalariesByMonth;
    }

    // Q3: Calculate the month-wise percentage growth of salaries for each employee
    public static Map<String, Map<Integer, Double>> calculatePercentageGrowth(List<Employee> employees) {
        Map<String, Map<Integer, Double>> percentageGrowth = new HashMap<>();

        try {
            for (Employee employee : employees) {
                Map<Integer, Double> growthMap = new HashMap<>();
                List<Salary> salaries = employee.getSalary();
                for (int i = 1; i < salaries.size(); i++)
                {
                    Salary currentSalary = salaries.get(i);
                    Salary previousSalary = salaries.get(i - 1);
                    double growth = ((double) (currentSalary.getAmount() - previousSalary.getAmount()) / previousSalary.getAmount()) * 100;
                    growthMap.put(currentSalary.getMonth(), growth);
                }
                percentageGrowth.put(employee.getName(), growthMap);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in calculatePercentageGrowth: " + e.getMessage());
            e.printStackTrace();
        }
        return percentageGrowth;
    }

    // Q4: Make a list of all the employees in the specified format
    public static List<String> createEmployeeList(List<Employee> employees) {
        List<String> employeeList = new ArrayList<>();

        try {
            for (Employee employee : employees) {
                int totalSalary = employee.getSalary().stream().mapToInt(Salary::getAmount).sum();
                String entry = String.format("%d_%s_%d_%s", employee.getId(), employee.getName(), totalSalary, employee.getCompany());
                employeeList.add(entry);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in createEmployeeList: " + e.getMessage());
            e.printStackTrace();
        }
        return employeeList;
    }

    // Q5: Make a company-wise map which shows the max salary given by the company each month
    public static Map<String, Map<Integer, Integer>> findCompanyWiseMaxSalaryByMonth(List<Employee> employees) {
        Map<String, Map<Integer, Integer>> companyWiseMaxSalaryByMonth = new HashMap<>();

        try {
            for (Employee employee : employees) {
                String company = employee.getCompany();
                companyWiseMaxSalaryByMonth.putIfAbsent(company, new HashMap<>());
                for (Salary salary : employee.getSalary()) {
                    int currentMonth = salary.getMonth();
                    int currentSalary = salary.getAmount();
                    int maxSalary = companyWiseMaxSalaryByMonth.get(company).getOrDefault(currentMonth, 0);
                    companyWiseMaxSalaryByMonth.get(company).put(currentMonth, Math.max(maxSalary, currentSalary));
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred in findCompanyWiseMaxSalaryByMonth: " + e.getMessage());
            e.printStackTrace();
        }

        return companyWiseMaxSalaryByMonth;
    }
}
