
class Salary {
    private int id;
    private int amount;
    private int month;
    private int year;

    public Salary(int id, int amount, int month, int year) {
        this.id = id;
        this.amount = amount;
        this.month = month;
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public int getAmount() {
        return amount;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }
}

